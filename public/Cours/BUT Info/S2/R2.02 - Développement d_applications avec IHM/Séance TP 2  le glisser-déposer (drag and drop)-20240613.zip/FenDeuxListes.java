
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;


public class FenDeuxListes extends Application { 
	// Les composants de la fen�tre
	private ListView<String> 	listeGauche	= new ListView<String>();
	private ListView<String>	listeDroite	= new ListView<String>();
	private Button 				bnTransfert	= new Button(">");
	// Les layout de la fen�tre
	private VBox zoneBoutons = new VBox();
	private HBox root = new HBox();
	
	
	public void start(Stage fenetre){ 
		fenetre.setTitle("DnD entre deux listes"); 
		fenetre.setResizable(false);
		Scene laScene = new Scene(creerSceneGraph());
		fenetre.setScene(laScene);
		fenetre.sizeToScene();
		fenetre.show();
	}
	
	
	private Pane creerSceneGraph(){
		for (int i=1 ; i<11 ; i++){
			listeGauche.getItems().add("El�ment "+i);
		}
		bnTransfert.setPrefWidth(80);

		zoneBoutons.setAlignment(Pos.TOP_CENTER);
		zoneBoutons.getChildren().addAll(bnTransfert);

		root.getChildren().addAll(listeGauche, zoneBoutons, listeDroite);

		return root;
	}
	
	
	static public void main(String args[]) {
		Application.launch();
	}
}