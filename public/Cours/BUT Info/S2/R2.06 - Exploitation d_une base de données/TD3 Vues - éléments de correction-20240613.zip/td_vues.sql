set schema 'TdVues';

-- Question 3
create view LannionProducteurs
as select *
   from producteur
   where ville = 'Lannion';

-----   
select * 
from LannionProducteurs;

select *
from producteur
where ville = 'Lannion';

-----
select raison_sociale
from lannionProducteurs;

select raison_sociale
from producteur
where ville = 'Lannion';

-- Question 5 
insert into lannionproducteurs 
  values ('SAS GIRAUMONT', 'Rennes');
-- L'insertion se passe bien dans la table source : producteur

select * 
from LannionProducteurs; 
-- Par contre, la vue ne fait pas apparaître le n-uplet car il ne correspond pas à 
-- la restriction de la vue (where ville = 'Lannion')

create or replace view lannionproducteurs
as select *
   from producteur
   where ville = 'Lannion' with check option;

insert into lannionproducteurs 
  values ('SAS LE GOFF', 'Lannion');
  
-- Question 6
CREATE VIEW NomsConsommateurs AS 
  SELECT nom, prenom
  FROM Consommateur;
  
CREATE VIEW ListeProduits AS 
  SELECT id, description
  FROM Produit;
  
insert into NomsConsommateurs
values ('Delhay','Arnaud');


-- Produits produits et consommés dans la même ville
create or replace view produits_meme_ville as
select produit.*
from produit inner join producteur
        on produit_par = raison_sociale
               inner join consommateur
        on consomme_par_login = login and consomme_par_email = email
where producteur.ville = consommateur.ville;

-- insertion impossible sur une vue qui lit plusieurs tables
insert into produits_meme_ville
values ('3', 'Banane', 'Duhamel', 'jdurand', 'jules.durand@gcris.fr');

-- update impossible dans une vue qui lit plusieurs tables
update produits_meme_ville
set description = 'Clémentine'
where id = 1;

-- delete
delete from produits_meme_ville
where id = 1;
